kubectl apply -f "C:\Users\sankalak\Desktop\Two-Node-POC\Two-Node-POC\helm-chart\postgres-operator\crds\" -n postgres

helm install postgres-operator "C:\Users\sankalak\Desktop\Two-Node-POC\Two-Node-POC\helm-chart\postgres-operator\" --values="C:\Users\sankalak\Desktop\Two-Node-POC\Two-Node-POC\helm-chart\postgres-operator\operator-values-overrides.yaml" --namespace=postgres --wait 


//kubectl get crd postgres.sql.tanzu.vmware.com


//kubectl create secret generic my-ca-certificate --type kubernetes.io/tls --from-file=ca.crt="C:\Users\santo\Desktop\Sandeep- Lloyds\poc-postgres\ca-cert\ca.crt" --from-file=tls.crt="C:\Users\santo\Desktop\Sandeep- Lloyds\poc-postgres\ca-cert\tls.crt" --from-file=tls.key="C:\Users\santo\Desktop\Sandeep- Lloyds\poc-postgres\ca-cert\tls.key" --namespace postgres